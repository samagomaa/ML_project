#!/usr/bin/env python
# coding: utf-8

# In[56]:


#libraries
import pandas as pd
import seaborn as sns
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt 
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_absolute_error 
from sklearn.metrics import mean_squared_error 
from sklearn.metrics import median_absolute_error
#from matplotlib.colors import ListedColormap
#import numpy as np
#import seaborn as sns


# In[57]:


#load dataset
df = pd.read_csv("E:/python/archive/Student_Performance.csv")


# In[58]:


#information about dataset
df.columns


# In[59]:


df.head()


# In[60]:


df.info()


# In[61]:


#feautre extraction
df["Precentage_of_Studing"]=df["Hours Studied"]/(24-df["Sleep Hours"])


# In[62]:


#preprocessing
df.isna().sum().sort_values() #no null


# In[63]:


df["Extracurricular Activities"]=df["Extracurricular Activities"].replace(to_replace=['No', 'Yes'], value=[0, 1])
df["Extracurricular Activities"] #encoded


# In[64]:


#Correlation Matrix
sns.heatmap(df.corr(), cmap='coolwarm', annot=True)
plt.show()


# In[78]:


#X-> feauters / y-> target
X = df.drop(["Performance Index"], axis=1).values
y = df["Performance Index"].values 


# In[79]:


df[['Previous Scores','Hours Studied','Sleep Hours','Sample Question Papers Practiced','Extracurricular Activities','Precentage_of_Studing']].boxplot()
plt.show() #no outliers


# In[80]:


#split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.32, random_state=29, shuffle =True)


# In[81]:


#
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)


# In[93]:


#train the LinearRegression model 
linearregression = LinearRegression()
linearregression.fit(X_train, y_train)


# In[94]:


y_pred=linearregression.predict(X_test)
y_pred[:5]


# In[95]:


y_test[:5]


# In[96]:


MAEValue = mean_absolute_error(y_test, y_pred)
MSEValue = mean_squared_error(y_test, y_pred)
MdSEValue = median_absolute_error(y_test, y_pred)
print(f"MAEValue is {MAEValue} \nMSEValue is {MSEValue} \nMdSEValue is {MdSEValue} ")


# In[97]:


train_score = linearregression.score(X_train, y_train)
test_score =linearregression.score(X_test, y_test)
print(f"Train_score is {train_score} \nTest_score is {test_score} ")


# In[100]:


fig = plt.figure(figsize = (8, 5))
sns.regplot(x = y_test, y = y_pred, line_kws = {'color':'red'})
plt.show()


# In[101]:


#Use grid search and choose best Hyperparameters 
param_grid = {'n_neighbors': list(range(1, 21)) ,'weights':('uniform','distance')}  #Define the parameter grid
# Create a KNN regressor
knn_regressor = KNeighborsRegressor()
# Use grid search with 10 cross-validation
grid_search = GridSearchCV(knn_regressor, param_grid, cv=10)
grid_search.fit(X_train, y_train)


# In[102]:


grid_search.best_params_


# In[103]:


grid_search.best_score_


# In[104]:


train_score = grid_search.score(X_train, y_train)
test_score =grid_search.score(X_test, y_test)
print(f"Train_score is {train_score} \nTest_score is {test_score} ")


# In[105]:


y_pred = grid_search.predict(X_test)
print(f"First 5 values in y pred is {y_pred[:5]} \nFirst 5 values in y test is {y_test[:5]} ")


# In[106]:


MAEValue = mean_absolute_error(y_test, y_pred)
MSEValue = mean_squared_error(y_test, y_pred)
MdSEValue = median_absolute_error(y_test, y_pred)
print(f"MAEValue is {MAEValue} \nMSEValue is {MSEValue} \nMdSEValue is {MdSEValue} ")


# In[107]:


fig = plt.figure(figsize = (8, 5))
sns.regplot(x = y_test, y = y_pred, line_kws = {'color':'red'})
plt.show()


# In[ ]:




